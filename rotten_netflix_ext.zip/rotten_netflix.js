var apiKey = "9udjy8ah39qedyb6eb6rd4p6"; // not used, but could use as a fallback.

function convertTitleToUrl(title) {
  var rtUrl = "http://www.rottentomatoes.com/m/";
  title = removeSubtitles(title);
  title = title.toLowerCase();
  title = replaceWordSeparators(title);
  title = replaceAmpersands(title);
  title = removeExtraneousCharacters(title);
  title = removeLeadingArticle(title);
  title = replaceAccentedLetters(title);
  rtUrl += title + "/";
  return rtUrl;
}

function removeSubtitles(title) {
  return title.replace(/(: Collector's Series|: Collector's Edition|: Director's Cut|: Special Edition)/, "");
}


function replaceWordSeparators(title) {
  return title.replace(/( |-)/g, "_");
}


function replaceAmpersands(title) {
  return title.replace(/&/g, "and");
}


function removeExtraneousCharacters(title) {
  return title.replace(/('|,|\.|!|\?|\/|:|\[|\]|\(|\))/g, "");
}


function removeLeadingArticle(title) {
  return title.replace(/^(the|a|an)_/, "");
}


function replaceAccentedLetters(title) {
  return title.replace(/(é|è)/g, "e");
}


function deSrcHTML(html) {
  return html.replace(/src/g, "foo");
}


$(document).ready(function(){
	
	$('.boxShot').each(function(){
		
		var imageEl = $(this).find('.boxShotImg');
		var movieTitle = imageEl.attr('alt');
		var movieUrl = convertTitleToUrl(movieTitle)
		
		$.ajax({
			url: movieUrl,
			dataType: 'html',
			success:function(data){
				var rating = $('#all-critics-meter', data).html();
				
				if(rating > 70){
					imageEl.parent().append("<a href='"+ movieUrl +"' class='rt_rating rt_fresh'><div class='icon'></div>"+ rating +"</a>")
	  			}
	  			else{
	  				imageEl.parent().append("<a href='"+ movieUrl +"' class='rt_rating rt_rotten'><div class='icon'></div>"+ rating +"</a>")
	  			}
			}
		});
	
	});
	
});
